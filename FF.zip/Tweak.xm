// Full menu.dylib cho Free Fire 1.123.18 + antiban qua eSign
// Biên dịch với Theos: Tweak.xm

#import <UIKit/UIKit.h>
#import <substrate.h>

static UIWindow *menuWindow;
static BOOL isMenuVisible = YES;

// ========== MENU UI ==========
void showMenu() {
    menuWindow = [[UIWindow alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 220)];
    menuWindow.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];
    menuWindow.windowLevel = UIWindowLevelAlert + 1;
    
    UIButton *espBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    espBtn.frame = CGRectMake(20, 30, 120, 40);
    [espBtn setTitle:@"ESP ON" forState:UIControlStateNormal];
    [espBtn setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    
    UIButton *aimBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    aimBtn.frame = CGRectMake(160, 30, 120, 40);
    [aimBtn setTitle:@"Aimlock ON" forState:UIControlStateNormal];
    
    UIButton *noRecoilBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    noRecoilBtn.frame = CGRectMake(20, 90, 120, 40);
    [noRecoilBtn setTitle:@"No Recoil ON" forState:UIControlStateNormal];
    
    UIButton *wallBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    wallBtn.frame = CGRectMake(160, 90, 120, 40);
    [wallBtn setTitle:@"Wallhack ON" forState:UIControlStateNormal];
    
    [menuWindow addSubview:espBtn];
    [menuWindow addSubview:aimBtn];
    [menuWindow addSubview:noRecoilBtn];
    [menuWindow addSubview:wallBtn];
    
    menuWindow.hidden = NO;
}

// ========== HOOK ANTIBAN ==========
%hook GGAntiCheatManager
- (BOOL)isGameTampered {
    return NO;
}
- (void)reportToServer:(id)data {
    // chặn gửi báo cáo
}
%end

%hook GGAntiMod
- (BOOL)checkDylibInjection {
    return NO;
}
- (void)flagModMenu {
    // vô hiệu
}
%end

%hook FFMemoryScanner
- (void)scan {
    // không làm gì
}
- (id)getSignature {
    return @"com.ff.original";
}
%end

// ========== HOOK CHEAT ==========
%hook PlayerEntity
- (void)setPosition:(CGPoint)pos {
    if (wallhackEnabled) pos = CGPointMake(pos.x, pos.y);
    %orig;
}
- (float)currentRecoil {
    if (noRecoilEnabled) return 0;
    return %orig;
}
%end

%hook EnemyManager
- (id)getEnemyArray {
    NSArray *arr = %orig;
    if (espEnabled) {
        for (id enemy in arr) {
            [enemy setValue:@1 forKey:@"_isVisible"];
        }
    }
    return arr;
}
%end

// ========== KHỞI TẠO ==========
%ctor {
    dispatch_async(dispatch_get_main_queue(), ^{
        showMenu();
    });
    NSLog(@"[FF] Menu + Antiban injected via eSign");
}